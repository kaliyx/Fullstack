// arreglar el toggle del perfil de usuario
// arreglar el toggle del perfil de usuario
function toggleProfile() {
    // Elimina <script> y ejecuta solo JS
    const btnLogin = document.getElementById('btn-login');
    const btnRegister = document.getElementById('btn-register');
    const btnProfile = document.getElementById('btn-profile');
    const perfilSection = document.getElementById('perfil-section');
    const btnLogout = document.getElementById('btn-logout');

    if (btnLogin) {
        btnLogin.onclick = function() {
            btnLogin.classList.add('d-none');
            btnRegister.classList.add('d-none');
            btnProfile.classList.remove('d-none');
            perfilSection.classList.remove('d-none');
        };
    }
    if (btnRegister) {
        btnRegister.onclick = function() {
            btnLogin.classList.add('d-none');
            btnRegister.classList.add('d-none');
            btnProfile.classList.remove('d-none');
            perfilSection.classList.remove('d-none');
        };
    }
    if (btnLogout) {
        btnLogout.onclick = function() {
            btnLogin.classList.remove('d-none');
            btnRegister.classList.remove('d-none');
            btnProfile.classList.add('d-none');
            perfilSection.classList.add('d-none');
        };
    }
}